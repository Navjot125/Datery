import { put, takeLatest } from 'redux-saga/effects';
import { SIGNOUT_REQUESTED } from './types';
import { signOutFail, signOutSuccess } from './actions';
import { API_URL } from '../../Constants/Config';
import axiosClient from '../../Utils/ApiClient';
import { REQUIRED_ERROR_MESSAGE } from '../../Constants/ErrorMessages';
import { CommonActions } from '@react-navigation/native';
import { removeAnswer, setAnswer } from '../SetAnswer/actions';
import { showAlert, showAlertError, showAlertSuccess } from '../../Common/Functions/CommonFunctions';
import { setLoader } from '../Loader/actions';
function* onDemoRequest({ data }) {
  // API CALL
  // RESULT
  // yield put(demoSuccess(data));
  // yield put(demoFail());
}

// function* onSignOutRequest({ data, navigation }) {
//   yield put(setLoader(true));
//   console.log(data, 'data', navigation, 'navigation --------------- ');
//   // yield put(setLoader(true));
//   let res = yield axiosClient
//     .post(navigation.endpoint, data)
//     .then(function (response) {
//       return response;
//     })
//     .catch(function (error) {
//       console.log('onLogin SAGA ERROR ===>', error);
//       return;
//     });
//   if (res) {
//     console.log(res.data, '....');
//     if (res?.data?.status) {
//       yield put(setLoader(false));
//       showAlertSuccess(res.data.message);
//       yield put(signOutSuccess(res.data));
//       // yield put(removeAnswer('all'))
//       // yield put(loginSuccess(res.data));
//       // showAlert(res.data.message);
//       console.log(res.data.message, ' message from saga login ');
//       navigation.changeRole({ user: 'Guest', id: 1 })
//       navigation.navigation();
//     } else {
//       yield put(setLoader(false));
//       showAlertError(res.data.message)
//       yield put(signOutFail());
//       // showAlert(res.data.message);
//       console.log(res.data.message);
//     }
//   } else {
//     yield put(setLoader(false));
//     showAlert(res.data.message)
//     console.log(REQUIRED_ERROR_MESSAGE);
//     // showAlert(ERROR_MESSAGE);
//   }
//   // yield put(setLoader(false));
// }

function* onSignOutRequest({ data, navigation }) {
  yield put(setLoader(true));
  console.log(data, 'data', navigation, 'navigation --------------- ');
      // yield put(setLoader(false));
      // showAlertSuccess('Sign out successfully');
      // yield put(signOutSuccess('success'));
      // // yield put(removeAnswer('all'))
      // // yield put(loginSuccess(res.data));
      // // showAlert(res.data.message);
      // yield put(changeRole({ user: 'Guest', id: 1 }))
      // navigation.navigation();
}

function* sagaSignOut() {
  yield takeLatest(SIGNOUT_REQUESTED, onSignOutRequest);
}
export default sagaSignOut;



