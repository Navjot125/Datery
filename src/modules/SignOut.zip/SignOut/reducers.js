import {SIGNOUT_FAIL, SIGNOUT_REQUESTED, SIGNOUT_SUCCESS} from './types';


const INITIAL_STATE = {
  demo: null,
  role: null,
  loginData: [],
  forgotPassData: null,
  otpVerificationData: [],
  resetPassData: null,
  deviceToken: null,
  userToken: null,
  datingData: [],
};

// {user: 'Guest', id: 1}
// {user: 'Login User', id: 2}

export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
      case SIGNOUT_REQUESTED:
      return {
        ...state,
      };

    case SIGNOUT_SUCCESS:
      return {
        ...state,
        loginData: [],
        userToken: null,
        datingData: [],
        role: null,
      };

    case SIGNOUT_FAIL:
      return {
        ...state,
      };

    default:
      return state;
  }
};
