import {SIGNOUT_FAIL, SIGNOUT_REQUESTED, SIGNOUT_SUCCESS} from './types';


export const signOutRequest = (data, navigation) => {
  return {
    type: SIGNOUT_REQUESTED,
    data,
    navigation,
  };
};

export const signOutSuccess = data => ({
  type: SIGNOUT_SUCCESS,
  data,
});

export const signOutFail = () => ({
  type: SIGNOUT_FAIL,
});
